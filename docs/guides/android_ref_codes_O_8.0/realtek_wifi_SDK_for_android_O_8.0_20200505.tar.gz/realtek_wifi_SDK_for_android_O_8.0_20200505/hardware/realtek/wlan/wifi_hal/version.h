#ifndef VERSION_H
#define VERSION_H

#define RTW_WIFI_HAL_VERSION "v1.0.3"

#endif /* VERSION_H */
