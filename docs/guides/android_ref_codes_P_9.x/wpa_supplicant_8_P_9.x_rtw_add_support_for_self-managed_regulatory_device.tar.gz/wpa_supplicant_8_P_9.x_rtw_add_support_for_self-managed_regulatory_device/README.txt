0001-nl80211-Handle-NL80211_CMD_WIPHY_REG_CHANGE-event.patch
0002-nl80211-Add-more-command-event-names-to-debug-prints.patch
0003-nl80211-Add-support-for-self-managed-regulatory-devi.patch
0004-nl80211-Read-reg-domain-information-from-a-specific-.patch
	Official patches in sequence to add support for self-managed regulatory device

add_support_for_self-managed_regulatory_device.patch
	Combined patch to add support for self-managed regulatory device